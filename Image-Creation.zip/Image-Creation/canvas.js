var canvas = document.querySelector ("myCanvas");
var ctx = canvas.getContext("2d");